from django.contrib import admin

from .models import *

admin.site.register(Segment)
admin.site.register(Gift)
admin.site.register(Competition)
admin.site.register(TeamCompetition)
admin.site.register(Coupons)