from django.contrib import admin
from .models import *


admin.site.register(Role)
admin.site.register(Volunteer)
admin.site.register(EntryStatus)
admin.site.register(GiftStatus)
